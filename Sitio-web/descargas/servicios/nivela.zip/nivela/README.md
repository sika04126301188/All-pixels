# Asesoría Nivela — Landing page de asesorías fiscales, contables y laborales para autónomos y pymes

Gracias por descargar **Asesoría Nivela** de All Pixels.
Es una landing page completa de **una sola página**, lista para personalizar y publicar.

- Versión: 1.0 · octubre de 2026
- Licencia: Gratis (lee `LICENCIA.txt`)
- Web: https://allpixels.dev

---

## Qué hay dentro del .zip

```
nivela/
├── README.md
├── LICENCIA.txt
├── fuentes/
│   ├── instrument-serif-italic.woff2
│   ├── instrument-serif.woff2
│   ├── OFL-InstrumentSerif.txt
│   ├── OFL-Outfit.txt
│   └── outfit-variable.woff2
├── iconos/
│   ├── abajo.svg
│   ├── calendario.svg
│   ├── check-cian.svg
│   ├── check.svg
│   ├── contable.svg
│   ├── correo.svg
│   ├── escudo.svg
│   ├── estrella.svg
│   ├── factura.svg
│   ├── fiscal.svg
│   ├── flecha-blanca.svg
│   ├── flecha.svg
│   ├── instagram.svg
│   ├── laboral.svg
│   ├── LICENCIA-ICONOS.txt
│   ├── linkedin.svg
│   ├── reloj.svg
│   ├── telefono.svg
│   ├── ubicacion.svg
│   └── whatsapp.svg
├── imagenes/
│   ├── analisis.jpg
│   ├── asesor-1.jpg
│   ├── asesor-2.jpg
│   ├── asesor-3.jpg
│   ├── asesor-4.jpg
│   ├── asesor-5.jpg
│   ├── contabilidad.jpg
│   ├── equipo-hero.jpg
│   ├── firma.jpg
│   ├── planificacion.jpg
│   └── reunion.jpg
└── index.html
```

## Verla en tu ordenador (sin instalar nada)

1. Descomprime el archivo .zip.
2. Abre la carpeta `nivela`.
3. Haz doble clic en `index.html`: se abrirá en tu navegador.

## Editarla

Te recomendamos un editor de código gratuito como **Visual Studio Code** (code.visualstudio.com).

| Quiero cambiar… | Dónde |
| --- | --- |
| Textos | `index.html` — secciones `#inicio`, `#servicios`, `#planes` y `#contacto`, y el pie |
| Documentos flotantes de la portada | la lista `<ul>` que va antes de la foto en `#inicio` |
| Opinión y cifras de la portada | el primer `<aside>` de `#inicio` (`<blockquote>` y `<dl>`) |
| Próximo vencimiento | se calcula solo con la fecha de hoy; las fechas están en el `<script>` final (`plazos`) |
| Revisión a fondo | segundo `<article>` de `#servicios`: una `<li>` por punto de control (el número va en `<data>`) |
| Calendario fiscal mes a mes | el `<aside>` de `#servicios`: una `<li>` por mes con su lista de tareas; `data-trimestral` marca los meses con impuestos trimestrales |
| Precios | `#planes`: atributos `data-mensual` y `data-anual` de cada `<data>` |
| Correo, teléfono y dirección | busca `hola@nivela.es`, `+34 910 000 000` y `Calle Mayor 12` |
| Colores | `index.html`, dentro de `<style>` — variables en `:root` (`--medianoche`, `--violeta`, `--cian`, `--lavanda`, `--niebla`, `--papel`) |
| Tipografía | `@font-face` al principio de `<style>` y carpeta `fuentes/` (Outfit e Instrument Serif) |
| Iconos | carpeta `iconos/` (SVG ya coloreados) |
| Fotos | carpeta `imagenes/` — sustitúyelas manteniendo el mismo nombre |

El HTML usa etiquetas semánticas sin clases y los estilos se aplican por etiqueta y posición (`section:nth-of-type(2)`, `article:nth-of-type(3)`). **Si añades o quitas una sección, revisa esos selectores.**

> **Antes de publicar:**
> 1. **Datos de ejemplo.** Las cifras (1.800+ clientes, 15+ años, 12 asesores, 36 puntos de control), la opinión, los nombres, los precios y los datos de contacto son de ejemplo: **sustitúyelos por los tuyos** y no publiques reseñas ni cifras que no puedas acreditar.
> 2. **Calendario fiscal.** Los plazos y modelos son orientativos (régimen general en España). Revísalos cada año con tu calendario oficial.
> 3. **Formulario.** «Habla hoy con tu asesor» es una demostración: no envía nada. Conéctalo a Formspree, Netlify Forms o tu propio servidor.
> 4. **Privacidad.** Si el formulario recoge datos, enlaza una política de privacidad real.

## Publicarla en internet

Puedes subir la carpeta completa a cualquier hosting. Las opciones más sencillas y gratuitas:

- **Netlify Drop** (app.netlify.com/drop): arrastra la carpeta y listo.
- **Cloudflare Pages** o el hosting de tu proveedor de dominio.

## Imágenes y créditos

- Las fotografías de la carpeta `imagenes/` son **solo de ejemplo** y **no están incluidas en la licencia de All Pixels**: sustitúyelas por fotos de tu equipo y tu oficina.
- Tipografías **Outfit** e **Instrument Serif**: SIL Open Font License 1.1 (textos de licencia en `fuentes/`). Están incluidas en la carpeta, así que la web no se conecta a Google Fonts.
- Iconos: **Font Awesome Free** — licencia CC BY 4.0 (ver `iconos/LICENCIA-ICONOS.txt`).

## Licencia

Licencia **Gratis**: puedes usarla en proyectos personales y comerciales, también para clientes. La única condición es mantener un crédito visible con enlace en el pie de la web:

```html
<a href="https://allpixels.dev">Plantilla de All Pixels</a>
```

No puedes revender ni redistribuir la plantilla como plantilla. Texto completo en `LICENCIA.txt`.

## ¿Necesitas ayuda?

Visita **https://allpixels.dev** para ver novedades y otras plantillas.

---

All Pixels · Cada píxel, listo para lanzar.
