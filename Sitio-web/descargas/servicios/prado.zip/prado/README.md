# Prado Sereno — Landing page de residencias caninas, guarderías de perros y cuidadores de mascotas

Gracias por descargar **Prado Sereno** de All Pixels.
Es una landing page completa de **una sola página**, lista para personalizar y publicar.

- Versión: 1.0 · octubre de 2026
- Licencia: Gratis (lee `LICENCIA.txt`)
- Web: https://allpixels.dev

---

## Qué hay dentro del .zip

```
prado/
├── README.md
├── LICENCIA.txt
├── decoracion/
│   ├── circulos.svg
│   ├── colinas-claras.svg
│   ├── colinas.svg
│   ├── manchas.svg
│   └── trazo.svg
├── fuentes/
│   ├── cormorant-garamond-500-italic.woff2
│   ├── cormorant-garamond-500-normal.woff2
│   ├── cormorant-garamond-600-normal.woff2
│   ├── nunito-variable.woff2
│   ├── OFL-Cormorant-Garamond.txt
│   └── OFL-Nunito.txt
├── iconos/
│   ├── arrow-right-blanco.svg
│   ├── arrow-right-tierra.svg
│   ├── bars-tierra.svg
│   ├── bone-taupe.svg
│   ├── bowl-food-taupe.svg
│   ├── calendar-days-taupe.svg
│   ├── camera-taupe.svg
│   ├── cat-taupe.svg
│   ├── check-naranja.svg
│   ├── clock-taupe.svg
│   ├── envelope-arena.svg
│   ├── hand-holding-heart-taupe.svg
│   ├── heart-naranja.svg
│   ├── house-taupe.svg
│   ├── instagram-arena.svg
│   ├── leaf-naranja.svg
│   ├── LICENCIA-ICONOS.txt
│   ├── location-dot-arena.svg
│   ├── moon-taupe.svg
│   ├── music-taupe.svg
│   ├── paw-blanco.svg
│   ├── paw-naranja.svg
│   ├── person-walking-taupe.svg
│   ├── phone-arena.svg
│   ├── shield-heart-taupe.svg
│   ├── shower-taupe.svg
│   ├── star-naranja.svg
│   ├── sun-naranja.svg
│   ├── tree-taupe.svg
│   ├── user-nurse-taupe.svg
│   ├── whatsapp-arena.svg
│   └── xmark-tierra.svg
├── imagenes/
│   ├── chihuahua-siames.jpg
│   ├── gatito-movil.jpg
│   ├── gatito-retrato.jpg
│   ├── gatito-saludo.jpg
│   ├── jerbos.jpg
│   ├── perro-gatito.jpg
│   └── perro-mirada.jpg
└── index.html
```

## Verla en tu ordenador (sin instalar nada)

1. Descomprime el archivo .zip.
2. Abre la carpeta `prado`.
3. Haz doble clic en `index.html`: se abrirá en tu navegador.

## Editarla

Te recomendamos un editor de código gratuito como **Visual Studio Code** (code.visualstudio.com).

| Quiero cambiar… | Dónde |
| --- | --- |
| Textos | `index.html` — secciones `#inicio`, `#casa`, `#dia`, `#tarifas`, `#familias` y `#reservar`, y el pie |
| Plazas de la portada | el `<aside>` de `#inicio`: el número de «Quedan…» y las `<li>` con `data-ocupada` (una por plaza ocupada) |
| Cinta de palabras | el `<p aria-hidden>` de `#inicio` (las dos `<span>` deben ser iguales para que el bucle no salte) |
| Horario del día | `#dia`: una `<li>` por actividad; la hora del atributo `datetime` decide qué se marca «Ahora mismo» |
| Precios | `#tarifas`: atributo `data-precios` de cada `<data>` (pequeño, mediano, grande) y el objeto `tarifas` del `<script>` final, que usa el formulario |
| Retratos de huéspedes | la lista `<ul>` de `#familias`: foto, nombre y número de mimos de cada `<li>` |
| Opiniones | los `<blockquote>` de `#familias` |
| Plazas libres por mes | `#reservar`: atributo `data-libres` de cada `<li>` (añade `data-pocas` para marcarla en naranja) |
| Teléfono, correo y dirección | busca `+34 600 000 000`, `hola@pradosereno.es` y `Camino del Prado` |
| Colores | `index.html`, dentro de `<style>` — variables en `:root` (`--naranja`, `--arena`, `--taupe`, `--tierra`, `--papel`) |
| Tipografía | `@font-face` al principio de `<style>` y carpeta `fuentes/` (Cormorant Garamond y Nunito) |
| Fondos decorativos | carpeta `decoracion/` (manchas, colinas, círculos y trazo, en SVG) |
| Iconos | carpeta `iconos/` (SVG ya coloreados) |
| Fotos | carpeta `imagenes/` — sustitúyelas manteniendo el mismo nombre |

El HTML usa etiquetas semánticas sin clases y los estilos se aplican por etiqueta y posición (`section:nth-of-type(4)`, `li:nth-of-type(2)`). **Si añades o quitas una sección, revisa esos selectores.**

> **Antes de publicar:**
> 1. **Datos de ejemplo.** Las cifras (3.000 m², 12 plazas, 4,9 de media en 320 opiniones), las opiniones, los nombres de los animales, los precios y los datos de contacto son de ejemplo: **sustitúyelos por los tuyos** y no publiques reseñas ni cifras que no puedas acreditar.
> 2. **Formulario.** «Solicitud de plaza» es una demostración: calcula un precio orientativo pero no envía nada. Conéctalo a Formspree, Netlify Forms o tu propio servidor.
> 3. **Mimos.** Los contadores de los retratos son decorativos y no se guardan.
> 4. **Privacidad.** Si el formulario recoge datos, enlaza una política de privacidad real.

## Publicarla en internet

Puedes subir la carpeta completa a cualquier hosting. Las opciones más sencillas y gratuitas:

- **Netlify Drop** (app.netlify.com/drop): arrastra la carpeta y listo.
- **Cloudflare Pages** o el hosting de tu proveedor de dominio.

## Imágenes y créditos

- Las fotografías de la carpeta `imagenes/` son **solo de ejemplo** y **no están incluidas en la licencia de All Pixels**: sustitúyelas por fotos de tus huéspedes y tus instalaciones.
- Fondos de `decoracion/`: creados a partir de formas generadas con Haikei y redibujados con la paleta de la plantilla.
- Tipografías **Cormorant Garamond** y **Nunito**: SIL Open Font License 1.1 (textos de licencia en `fuentes/`). Están incluidas en la carpeta, así que la web no se conecta a Google Fonts.
- Iconos: **Font Awesome Free** — licencia CC BY 4.0 (ver `iconos/LICENCIA-ICONOS.txt`).

## Licencia

Licencia **Gratis**: puedes usarla en proyectos personales y comerciales, también para clientes. La única condición es mantener un crédito visible con enlace en el pie de la web:

```html
<a href="https://allpixels.dev">Plantilla de All Pixels</a>
```

No puedes revender ni redistribuir la plantilla como plantilla. Texto completo en `LICENCIA.txt`.

## ¿Necesitas ayuda?

Visita **https://allpixels.dev** para ver novedades y otras plantillas.

---

All Pixels · Cada píxel, listo para lanzar.
