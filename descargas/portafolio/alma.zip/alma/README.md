# ALMA Studio — Landing page de estudios de arquitectura, interiorismo y paisajismo

Gracias por descargar **ALMA Studio** de All Pixels.
Es una landing page completa de **una sola página**, lista para personalizar y publicar.

- Versión: 1.0 · octubre de 2026
- Licencia: Gratis (lee `LICENCIA.txt`)
- Web: https://allpixels.dev

---

## Qué hay dentro del .zip

```
alma/
├── README.md
├── LICENCIA.txt
├── fonts/
│   ├── cormorant-garamond-latin-400-italic.woff2
│   ├── cormorant-garamond-latin-400-normal.woff2
│   ├── cormorant-garamond-latin-600-normal.woff2
│   ├── cormorant-garamond-latin-700-normal.woff2
│   ├── inter-latin-300-normal.woff2
│   ├── inter-latin-400-normal.woff2
│   ├── inter-latin-500-normal.woff2
│   ├── inter-latin-600-normal.woff2
│   ├── OFL-Cormorant-Garamond.txt
│   └── OFL-Inter.txt
├── img/
│   ├── casa-eucalipto.jpg
│   ├── hero-detalle.jpg
│   ├── hero-principal.jpg
│   ├── lounge-piedra.jpg
│   └── pabellon-meditacion.jpg
├── index.html
└── style.css
```

## Verla en tu ordenador (sin instalar nada)

1. Descomprime el archivo .zip.
2. Abre la carpeta `alma`.
3. Haz doble clic en `index.html`: se abrirá en tu navegador.

## Editarla

Te recomendamos un editor de código gratuito como **Visual Studio Code** (code.visualstudio.com).

| Quiero cambiar… | Dónde |
| --- | --- |
| Textos | `index.html` — secciones `#inicio`, `#filosofia`, `#obras` y `#contacto` |
| Colores | `style.css` — apartado **2. Variables** (`--olive`, `--olive-deep`, `--wood`, `--linen`…) |
| Tipografías | `style.css`, apartado **1** y carpeta `fonts/` |
| Estilos de cada sección | `style.css` — apartados 4 a 9, uno por sección |
| Menú, aparición al bajar y formulario | `index.html`, al final, dentro de `<script>` |
| Fotos | carpeta `img/` — sustitúyelas manteniendo el mismo nombre (y actualiza `width`/`height` y `alt` en el HTML si cambian) |

> **Antes de publicar:**
> 1. **Formulario.** Ahora mismo no envía nada: muestra un aviso de ejemplo. Conéctalo a Formspree (formspree.io) o similar cambiando `action="#"` por la dirección que te den; el script deja entonces que el envío se haga normalmente.
> 2. **Enlaces.** La política de privacidad del formulario y las redes sociales del pie apuntan a `#`: enlázalos a tus páginas reales.
> 3. **Datos de ejemplo.** ALMA Studio es una marca inventada. La dirección, el email (`info@almastudio.example`), los proyectos y las cifras («15+ años», «100 %») son de ejemplo: **sustitúyelos por datos reales** y no publiques cifras inventadas.
> 4. **Fotos.** Lo ideal es poner fotos de tus propias obras.

## Publicarla en internet

Puedes subir la carpeta completa a cualquier hosting. Las opciones más sencillas y gratuitas:

- **Netlify Drop** (app.netlify.com/drop): arrastra la carpeta y listo.
- **Cloudflare Pages** o el hosting de tu proveedor de dominio.

## Imágenes y créditos

- Las fotografías de la carpeta `img/` proceden de **Unsplash** (unsplash.com) y se usan bajo la licencia de Unsplash: puedes usarlas gratis en tu web, también con fines comerciales. **No están incluidas en la licencia de All Pixels**: no puedes vender las fotos sin modificar ni usarlas para crear un servicio de fotos parecido.
- Tipografías **Cormorant Garamond** e **Inter**: SIL Open Font License 1.1 (textos de licencia en `fonts/`). Están incluidas en la carpeta, así que la web no se conecta a Google Fonts.

## Licencia

Licencia **Gratis**: puedes usarla en proyectos personales y comerciales, también para clientes. La única condición es mantener un crédito visible con enlace en el pie de la web:

```html
<a href="https://allpixels.dev">Plantilla de All Pixels</a>
```

No puedes revender ni redistribuir la plantilla como plantilla. Texto completo en `LICENCIA.txt`.

## ¿Necesitas ayuda?

Visita **https://allpixels.dev** para ver novedades y otras plantillas.

---

All Pixels · Cada píxel, listo para lanzar.
